-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!


-- 1. feladat:


-- 3. feladat:


-- 4. feladat:


-- 5. feladat:


-- 6. feladat:

